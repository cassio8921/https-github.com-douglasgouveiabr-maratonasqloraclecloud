  insert into cidades
      (id_cidade 
      ,nome  
      ,data_criacao 
      ,data_atualizacao 
      )
  values(1
        ,'São Paulo' --nome  
        ,sysdate --data_criacao 
        ,sysdate --data_atualizacao 
        );
        
  insert into cidades
      (id_cidade 
      ,nome  
      ,data_criacao 
      ,data_atualizacao 
      )
  values(2
        ,'Rio de Janeiro' --nome  
        ,sysdate --data_criacao 
        ,sysdate --data_atualizacao 
        );
        
  insert into cidades
      (id_cidade 
      ,nome  
      ,data_criacao 
      ,data_atualizacao 
      )
  values(3
        ,'Curitiba' --nome  
        ,sysdate --data_criacao 
        ,sysdate --data_atualizacao 
        );