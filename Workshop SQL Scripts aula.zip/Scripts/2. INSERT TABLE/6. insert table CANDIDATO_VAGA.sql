
INSERT INTO CANDIDATO_VAGA
          (id_vaga           
		  ,id_candidato      
		  ,data_inscricao     
          ,data_criacao       
          ,data_atualizacao   
          )
    values(1
          ,1
          ,sysdate
          ,sysdate
          ,sysdate);
      
INSERT INTO CANDIDATO_VAGA
          (id_vaga           
		  ,id_candidato      
		  ,data_inscricao     
          ,data_criacao       
          ,data_atualizacao   
          )
    values(1
          ,2
          ,sysdate
          ,sysdate
          ,sysdate);
      
INSERT INTO CANDIDATO_VAGA
          (id_vaga           
		  ,id_candidato      
		  ,data_inscricao     
          ,data_criacao       
          ,data_atualizacao   
          )
    values(2
          ,2
          ,sysdate
          ,sysdate
          ,sysdate);
      

INSERT INTO CANDIDATO_VAGA
          (id_vaga           
		  ,id_candidato      
		  ,data_inscricao     
          ,data_criacao       
          ,data_atualizacao   
          )
    values(3
          ,1
          ,sysdate
          ,sysdate
          ,sysdate);

INSERT INTO CANDIDATO_VAGA
          (id_vaga           
		  ,id_candidato      
		  ,data_inscricao     
          ,data_criacao       
          ,data_atualizacao   
          )
    values(3
          ,3
          ,sysdate
          ,sysdate
          ,sysdate);
      