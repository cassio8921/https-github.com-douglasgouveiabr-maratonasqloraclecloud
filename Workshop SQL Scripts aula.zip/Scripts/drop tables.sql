drop table CANDIDATO_VAGA;
drop table VAGAS;
drop table CANDIDATOS;
drop table EMPRESAS;
drop table cidades;
drop table estados;