CREATE TABLE CANDIDATO_VAGA
          (id_vaga            number not null 
		  ,id_candidato       number not null 
		  ,data_inscricao     date not null
          ,data_criacao       date not null
          ,data_atualizacao   date not null
          );
          