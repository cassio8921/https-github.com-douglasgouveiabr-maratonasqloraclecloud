--1) Listar candidados por cidade
select can.nome, can.email, can.fone, cid.nome cidade
  from candidatos can
      ,cidades cid
 where can.id_cidade = cid.id_cidade
 
--2) Incluir estado 
select can.nome, can.email, can.fone, cid.nome cidade, uf.sigla
  from candidatos can
      ,cidades cid
      ,estados uf
 where can.id_cidade = cid.id_cidade
   and uf.id_estado = can.id_estado
   
--3)Atualizar o estado do Tony Stark ele mudou para SP
update candidatos
   set id_estado = 1 
where nome = 'Tony Stark'

--4)Listas as vagas em aberto por empresa 
select emp.cnpj, emp.razao_social, emp.contato, vg.titulo , vg.status , vg.codigo
  from empresas emp
     , vagas vg
 where emp.id_emp = vg.id_emp     
     
--5) atualizar status vaga da DELL  

update vagas
set status = 'Fechado'
where codigo = 'VAGA002'

--6) deletar cadastro Michael Jackson

delete candidatos 
where id_candidato = 2 

delete candidato_vaga where id_candidato = 2 
 
 
--7) Listar vagas ordenado pelo valor do salário 
select * 
  from vagas   
order by faixa_sal    

--8) Quanto é o maior salario das vagas em aberto? 
select max(faixa_sal) from vagas where status = 'Aberto'

--9) listar vagas SQL 
 select * from vagas where upper(descricao) like '%SQL%'
 
--10) Listar vagas por estado 
select uf.sigla, count(1)
 from vagas vg
   , estados uf
where uf.id_estado = vg.id_estado 
group by uf.sigla 