insert into CANDIDATOS
          (id_candidato
		  ,nome               
		  ,email              
          ,senha              
          ,data_nasc          
          ,genero             
          ,estado_civil                   
          ,qtde_filhos        
          ,tipo_doc           
          ,nr_documento       
          ,endereco           
          ,id_cidade          
          ,id_estado          
          ,fone               
          ,linkedin           
          ,pcd                
          ,resumo_prof        
          ,formacao_academica   
          ,hist_profissional     
          ,nivel_ingles       
          ,pret_salarial      
          ,complemento            
          ,data_cadastro      
          ,data_atualizacao   
          )
   values (1
          ,'Tony Stark' --nome               varchar2(150) not null
		  ,'tonystark@gmai.com'   --email              varchar2(100) not null
          ,'123mudar' --senha              varchar2(12) not null
          ,to_date('10/04/1987','DD/MM/YYYY') --data_nasc          date not null
          ,'M' --genero             char(1)
          ,'Casado' --estado_civil       varchar2(10)                
          ,3 --qtde_filhos        number
          ,'CPF' --tipo_doc           varchar2(10)
          ,'30012345620' --nr_documento       varchar2(15)
          ,'Av. Paulista 1000, centro' --endereco           varchar2(150)
          ,1 --id_cidade          number
          ,2 --id_estado          number
          ,'11 98791234'          --fone               varchar2(30) not null
          ,NULL --linkedin           varchar2(150)
          ,'N' --pcd                char(1)
          ,'Profissional com mais de 5 anos de experiência no mercado atuando com SQL' --resumo_prof        varchar2(2000) not null
          ,'Pós Graduação em Banco de Dados Oracle' --formacao_academica varchar2(2000)    
          ,'Atuou em empresas como DELL, Oracle, Genral Eletric, Deloitte, etc... ' --hist_profissional  varchar2(2000)    
          ,'Intermediário' --nivel_ingles       varchar2(30)
          ,null --pret_salarial      number
          ,null --complemento        varchar2(2000)    
          ,sysdate --data_cadastro      date not null
          ,sysdate --data_atualizacao   date not null
          );
          
insert into CANDIDATOS
          (id_candidato
		  ,nome               
		  ,email              
          ,senha              
          ,data_nasc          
          ,genero             
          ,estado_civil                   
          ,qtde_filhos        
          ,tipo_doc           
          ,nr_documento       
          ,endereco           
          ,id_cidade          
          ,id_estado          
          ,fone               
          ,linkedin           
          ,pcd                
          ,resumo_prof        
          ,formacao_academica   
          ,hist_profissional     
          ,nivel_ingles       
          ,pret_salarial      
          ,complemento            
          ,data_cadastro      
          ,data_atualizacao   
          )
   values (2
          ,'Michael Jackson' --nome               varchar2(150) not null
		  ,'mjackson@gmai.com'   --email              varchar2(100) not null
          ,'123mudar' --senha              varchar2(12) not null
          ,to_date('29/08/1958','DD/MM/YYYY') --data_nasc          date not null
          ,'M' --genero             char(1)
          ,'Solteiro' --estado_civil       varchar2(10)                
          ,0 --qtde_filhos        number
          ,'CPF' --tipo_doc           varchar2(10)
          ,'30112345630' --nr_documento       varchar2(15)
          ,'Av. atlantica 20, copacabana' --endereco           varchar2(150)
          ,2 --id_cidade          number
          ,2 --id_estado          number
          ,'21 98791234'          --fone               varchar2(30) not null
          ,NULL --linkedin           varchar2(150)
          ,'N' --pcd                char(1)
          ,'Cursando o segundo ano de ciencia da computação, conhecimento de lógica de programação e SQL' --resumo_prof        varchar2(2000) not null
          ,'Superior Incompleto' --formacao_academica varchar2(2000)    
          ,'Atua como free lancer há 1 ano, prestando serviços pontuais e desenvolvendo projetos pessoais em paralelo. ' --hist_profissional  varchar2(2000)    
          ,'Avançado' --nivel_ingles       varchar2(30)
          ,null --pret_salarial      number
          ,null --complemento        varchar2(2000)    
          ,sysdate --data_cadastro      date not null
          ,sysdate --data_atualizacao   date not null
          );
  
  
insert into CANDIDATOS
          (id_candidato
		  ,nome               
		  ,email              
          ,senha              
          ,data_nasc          
          ,genero             
          ,estado_civil                   
          ,qtde_filhos        
          ,tipo_doc           
          ,nr_documento       
          ,endereco           
          ,id_cidade          
          ,id_estado          
          ,fone               
          ,linkedin           
          ,pcd                
          ,resumo_prof        
          ,formacao_academica   
          ,hist_profissional     
          ,nivel_ingles       
          ,pret_salarial      
          ,complemento            
          ,data_cadastro      
          ,data_atualizacao   
          )
   values (3
          ,'Gisele Bundchen' --nome               varchar2(150) not null
		  ,'giseleb@gmai.com'   --email              varchar2(100) not null
          ,'123mudar' --senha              varchar2(12) not null
          ,to_date('20/07/1980','DD/MM/YYYY') --data_nasc          date not null
          ,'F' --genero             char(1)
          ,'Casado' --estado_civil       varchar2(10)                
          ,0 --qtde_filhos        number
          ,'CPF' --tipo_doc           varchar2(10)
          ,'20912345640' --nr_documento       varchar2(15)
          ,'Av. do Batel, 100, bairro: Batel' --endereco           varchar2(150)
          ,3 --id_cidade          number
          ,3 --id_estado          number
          ,'41 98762233'          --fone               varchar2(30) not null
          ,NULL --linkedin           varchar2(150)
          ,'N' --pcd                char(1)
          ,'Supermodelo, filantropa, ativista ambiental e empresária brasileira. Desde 2004, esteve entre as modelos mais bem pagas do mundo e, a partir de 2007, tornou-se a 16.ª mulher mais rica do setor de entretenimento.' --resumo_prof        varchar2(2000) not null
          ,'Superior' --formacao_academica varchar2(2000)    
          ,'Entusiasta de tecnologia, para aplicar em seus projetos de filantropia e setor da moda. ' --hist_profissional  varchar2(2000)    
          ,'Fluente' --nivel_ingles       varchar2(30)
          ,null --pret_salarial      number
          ,null --complemento        varchar2(2000)    
          ,sysdate --data_cadastro      date not null
          ,sysdate --data_atualizacao   date not null
          );
          
  

          

          
