   insert into estados
      (id_estado 
	  ,nome  
      ,sigla
      ,data_criacao 
      ,data_atualizacao 
      )
  values(1
        ,'São Paulo' --nome  
        ,'SP' --sigla
        ,sysdate --data_criacao 
        ,sysdate --data_atualizacao 
        );
        
    insert into estados
      (id_estado 
	  ,nome  
      ,sigla
      ,data_criacao 
      ,data_atualizacao 
      )
  values(2
        ,'Rio de Janeiro' --nome  
        ,'RJ' --sigla
        ,sysdate --data_criacao 
        ,sysdate --data_atualizacao 
        ); 
        
   insert into estados
      (id_estado 
	  ,nome  
      ,sigla
      ,data_criacao 
      ,data_atualizacao 
      )
  values(3
        ,'Paraná' --nome  
        ,'PR' --sigla
        ,sysdate --data_criacao 
        ,sysdate --data_atualizacao 
        );
 
        
 
  