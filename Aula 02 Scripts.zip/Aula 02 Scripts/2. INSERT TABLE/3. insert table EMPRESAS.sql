                insert into EMPRESAS (id_emp
                               ,cnpj
                               ,razao_social
                               ,nome_fantasia
                               ,email
                               ,contato
                               ,nome_contato
                               ,sobre_empresa
                               ,data_criacao
                               ,data_atualizacao
                               )
                     values (1 --ID_EMP
                            ,'05.623.414/0001-90'          --CNPJ
                            ,'Oracle do Brasil Sistemas'  --razao_social
                            ,'Oracle do Brasil' --nome_fantasia
                            ,'rh@oracle.com' --email
                            , '11 5189-1000' --contato
                            ,'Paulo' --nome_contato
                            --sobre_empresa
                            ,'Fundada em 1977 por Larry Ellison, Bob Miner, Ed Oates, a Oracle Corporation é uma multinacional que atua na área de computação e informática, com especialização no desenvolvimento e distribuição de soluções de banco de dados, sistemas em nuvem e de softwares corporativos.'
                            ,sysdate --data_criacao
                            ,sysdate --data_atualizacao
                            );


               insert into EMPRESAS (id_emp
                               ,cnpj
                               ,razao_social
                               ,nome_fantasia
                               ,email
                               ,contato
                               ,nome_contato
                               ,sobre_empresa
                               ,data_criacao
                               ,data_atualizacao
                               )
                     values (2 --ID_EMP
                            ,'44.772.123/0001-16'          --CNPJ
                            ,'Dell Corporation'  --razao_social
                            ,'Dell Computers Brasil' --nome_fantasia
                            ,'rh@dell.com' --email
                            , '51 3210-1234' --contato
                            ,'Pedro' --nome_contato
                            --sobre_empresa
                            ,'Aqui na Dell Technologies, existem infinitos desafios e recompensas. Oportunidades por todo o mundo. Um time alimentado por colaboração. Uma cultura que cultiva inovação e valores como um espaço de trabalho inclusivo e diverso. Nós somos feitos de pessoas fortes e inteligentes, dedicadas a fazerem o seu melhor trabalho e impulsionar sucesso aos nossos clientes.'
                            ,sysdate --data_criacao
                            ,sysdate --data_atualizacao
                            );
                
               insert into EMPRESAS (id_emp
                               ,cnpj
                               ,razao_social
                               ,nome_fantasia
                               ,email
                               ,contato
                               ,nome_contato
                               ,sobre_empresa
                               ,data_criacao
                               ,data_atualizacao
                               )
                     values (3 --ID_EMP
                            ,'12.542.221/0001-70'          --CNPJ
                            ,'Accenture Corporation BR'  --razao_social
                            ,'Accenture Brasil' --nome_fantasia
                            ,'rh@accenture.com' --email
                            , '11 3322-1234' --contato
                            ,'Maria' --nome_contato
                            --sobre_empresa
                            ,'Somos um time global com mais de 710 mil profissionais no mundo todo, Nossos valores moldam a cultura da nossa organização e definem o caráter de nossa companhia. Vivemos os valores essenciais por meio dos comportamentos individuais. Eles são os pilares para nossa forma de agir e de tomar decisões.'
                            ,sysdate --data_criacao
                            ,sysdate --data_atualizacao
                            );
                        