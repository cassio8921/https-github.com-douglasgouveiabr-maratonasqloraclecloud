alter table EMPRESAS add constraint PK_empresas primary key (id_emp);

--ESTADO
alter table estados add constraint PK_estados primary key (id_estado);

--CIDADE
alter table cidades add constraint PK_cidades primary key (id_cidade);

--CANDIDATOS
alter table CANDIDATOS add constraint PK_candidato primary key (id_candidato);
alter table CANDIDATOS add constraint FK_cidade_candidato FOREIGN KEY(id_cidade) REFERENCES CIDADES(id_cidade);
alter table CANDIDATOS add constraint FK_estado_candidato FOREIGN KEY(id_estado) REFERENCES ESTADOS(id_estado);

--VAGAS
alter table vagas add constraint PK_vaga primary key (ID_VAGA);
alter table vagas add constraint FK_empresa_vaga FOREIGN KEY(id_emp)    REFERENCES empresas(id_emp);
alter table vagas add constraint FK_cidade_vaga  FOREIGN KEY(id_cidade) REFERENCES CIDADES(id_cidade);
alter table vagas add constraint FK_estado_vaga  FOREIGN KEY(id_estado) REFERENCES ESTADOS(id_estado);

--CANDIDATO_VAGA
alter table candidato_vaga add constraint PK_candidato_vaga primary key (ID_VAGA,id_candidato);
alter table candidato_vaga add constraint FK_candidato_vaga_id_vaga  FOREIGN KEY(id_vaga) REFERENCES VAGAS(id_vaga);
alter table candidato_vaga add constraint FK_candidato_vaga_id_candidato  FOREIGN KEY(id_candidato) REFERENCES candidatos(id_candidato);


